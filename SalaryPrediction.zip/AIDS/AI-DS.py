#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Importing essential libraries
import numpy as np
import pandas as pd
# Loading the dataset
df = pd.read_csv("C:\\Users\\manas\\OneDrive\\Desktop\\job_salary.csv")
#Exploring the dataset
# Returns number of rows and columns of the dataset
df.shape


# In[2]:


df.columns


# In[3]:


df.dtypes


# In[4]:


df.head()


# In[5]:


df.tail()


# In[6]:


df.info()


# In[7]:


df.describe().T


# In[8]:


# Returns true for a column having null values, else false
df.isnull().any()


# In[9]:


# Removing the 'Unnamed' column
df.drop(labels='Unnamed: 0', axis='columns', inplace=True)
df.columns


# In[10]:


# Removing the rows having '-1' as Salary Estimate value
print("Before: ",df.shape)
df = df[df['Salary Estimate'] != "-1"]
print("After: ", df.shape)


# In[11]:


# Removing the text value from 'Salary Estimate' column
salary = df['Salary Estimate'].apply(lambda x: x.split("(")[0])
salary


# In[12]:


# Removing '$' and 'K' from 'Salary Estimate' column
salary = salary.apply(lambda x: x.replace("$","").replace("K",""))
salary


# In[13]:


# Finding any inconsistencies in the salary
print("Length of Salary: ",len(salary.unique()))
salary.unique()[380:]


# In[16]:


# Creating column for 'Per Hour'
df['salary_per_hour'] = salary.apply(lambda x: 1 if "per hour" in x.lower() else 0)
df['salary_per_hour'].value_counts()


# In[17]:


# Creating column for 'Employee Provided Salary'
df['emp_provided_salary'] = salary.apply(lambda x: 1 if "employer provided salary" in x.lower() else 0)
df['emp_provided_salary'].value_counts()


# In[18]:


# Removing 'Per Hour' and 'Employer Provided Salary' from 'Salary Estimate' column
salary = salary.apply(lambda x: x.lower().replace("per hour", "").replace("employer provided salary:", "").replace(" ",""))
salary.unique()[380:]


# In[19]:


# Creating column for min_salary
df["min_salary"] = salary.apply(lambda x: int(x.split("-")[0]))
df["min_salary"].tail()


# In[20]:


# Creating column for max_salary
df["max_salary"] = salary.apply(lambda x: int(x.split("-")[1]))
df["max_salary"].tail()


# In[21]:


# Creating column for average_salary
df["average_salary"] = (df["min_salary"]+df["max_salary"])/2
# Converting the hourly salaries to annual salaries
df['min_salary'] = df.apply(lambda x: x['min_salary']*2 if x['salary_per_hour'] == 1 else x['min_salary'], axis=1)
df['max_salary'] = df.apply(lambda x: x['max_salary']*2 if x['salary_per_hour'] == 1 else x['max_salary'], axis=1)
df[df['salary_per_hour'] == 1][['salary_per_hour','min_salary','max_salary']]


# In[22]:


# Removing numbers from 'Company Name' column
df["Company Name"] = df['Company Name'].apply(lambda x: x.split("\n")[0])
df["Company Name"].head(10)


# In[23]:


# Creating a column 'job_state'
df["job_state"] = df["Location"].apply(lambda x: x.split(',')[1])
df["job_state"].head()


# In[24]:


df['job_state'].unique()


# In[25]:


# Fixing Los Angeles to CA
df['job_state'] = df['job_state'].apply(lambda x: x.strip() if x.strip().lower() != 'los angeles' else 'CA')
df['job_state'].value_counts()[:5]


# In[26]:


df['job_state'].unique()


# In[27]:


# Calculating age of the companies
df["company_age"] = df['Founded'].apply(lambda x: x if x<1 else 2020-x)
df["company_age"].head()


# In[28]:


# Cleaning the 'Job Description' column
df["python_job"] = df['Job Description'].apply(lambda x: 1 if 'python' in x.lower() else 0)
df["r_job"] = df['Job Description'].apply(lambda x: 1 if 'r studio' in x.lower() else 0)
df["spark_job"] = df['Job Description'].apply(lambda x: 1 if 'spark' in x.lower() else 0)
df["aws_job"] = df['Job Description'].apply(lambda x: 1 if 'aws' in x.lower() else 0)
df["excel_job"] = df['Job Description'].apply(lambda x: 1 if 'excel' in x.lower() else 0)


# In[29]:


# Python Jobs
df.python_job.value_counts()


# In[30]:


# R Studio Jobs
df.r_job.value_counts()


# In[31]:


# Spark Jobs
df.spark_job.value_counts()


# In[32]:


# AWS Jobs
df.aws_job.value_counts()


# In[33]:


# Excel Jobs
df.excel_job.value_counts()


# In[34]:


# Dataset till now
df.head()


# In[35]:


# Cleaning the 'Job Title' column
def title_simplifier(title):
    if 'data scientist' in title.lower():
        return 'data scientist'
    elif 'data engineer' in title.lower():
        return 'data engineer'
    elif 'analyst' in title.lower():
        return 'analyst'
    elif 'machine learning' in title.lower():
        return 'mle'
    elif 'manager' in title.lower():
        return 'manager'
    elif 'director' in title.lower():
        return 'director'
    else:
        return 'na'

df['job_title_simplified'] = df['Job Title'].apply(title_simplifier)
df['job_title_simplified'].value_counts()


# In[36]:


def seniority(title):
    if 'sr' in title.lower() or 'senior' in title.lower() or 'sr' in title.lower() or 'lead' in title.lower() or 'principal' in title.lower():
            return 'senior'
    elif 'jr' in title.lower() or 'jr.' in title.lower():
        return 'jr'
    else:
        return 'na'

df['job_seniority'] = df['Job Title'].apply(seniority)
df['job_seniority'].value_counts()


# In[37]:


# Cleaning 'Competitors' column
df['Competitors'] = df['Competitors'].apply(lambda x: len(x.split(',')) if x != '-1' else 0)
df['Competitors']


# In[38]:


# Cleaning 'Type of Ownership' column
df['Type of ownership'].value_counts()


# In[39]:


def ownership_simplifier(text):
    if 'private' in text.lower():
      return 'Private'
    elif 'public' in text.lower():
      return 'Public'
    elif ('-1' in text.lower()) or ('unknown' in text.lower()):
      return 'Other Organization'
    else:
      return text

df['Type of ownership'] = df['Type of ownership'].apply(ownership_simplifier)
df['Type of ownership'].value_counts()


# In[40]:


# Cleaning 'Revenue' column
df['Revenue'].value_counts()


# In[41]:


def revenue_simplifier(text):
  if '-1' in text.lower():
    return 'Unknown / Non-Applicable'
  else:
    return text

df['Revenue'] = df['Revenue'].apply(revenue_simplifier)
df['Revenue'].value_counts()


# In[42]:


df['Size'].value_counts()


# In[43]:


# Cleaning 'Size' column
def size_simplifier(text):
  if '-1' in text.lower():
    return 'Unknown'
  else:
    return text

df['Size'] = df['Size'].apply(size_simplifier)
df['Size'].value_counts()


# In[44]:


# Dataset till now
df.head()


# In[46]:


# Exploratory Data Analysis
# Importing essential libraries
import matplotlib.pyplot as plt
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')
df.describe().T


# In[47]:


df['Rating'].hist()
plt.xlabel('Ratings')
plt.ylabel('Count')
plt.title('Company Ratings Histogram')


# In[48]:


df['company_age'].hist()
plt.xlabel('Time(in Years)')
plt.ylabel('Count')
plt.title('Companies Age Histogram')


# In[49]:


df['average_salary'].hist()
plt.xlabel('Annual Salary (in $)')
plt.ylabel('Count')
plt.title('Average Salary Histogram')


# In[50]:


sns.boxplot(y='average_salary', data=df, orient='v' , palette='Set1')


# In[51]:


sns.boxplot(y='company_age', data=df, orient='v' , palette='Set1')


# In[52]:


sns.boxplot(y='Rating', data=df, orient='v' , palette='Set1')


# In[53]:


#co-relation b/w columns
df[['company_age','average_salary','Rating']].corr()


# In[54]:


#plotting co-relation
sns.set()
sns.heatmap(df[['company_age', 'average_salary', 'Rating']].corr(), annot=True, fmt='.1f')
plt.yticks(rotation = 0)


# In[55]:


df.columns


# In[56]:


df.dtypes


# In[57]:


#objects
df_categorical = df[['Company Name', 'Location', 'Headquarters', 'Size', 'Founded',
       'Type of ownership', 'Industry', 'Sector', 'Revenue', 'job_title_simplified',
       'job_seniority']]
#plotting data for location & headquaters
for i in['Location', 'Headquarters','Company Name','Size','Type of ownership','Revenue','Industry','Sector', 'job_title_simplified',
       'job_seniority']:
    unique_categories = df_categorical[i].value_counts()[:20]
    print("Graph for {}\n Total records={}".format(i, len(unique_categories)))
    chart = sns.barplot(x=unique_categories.index, y=unique_categories)
    chart.set_xticklabels(chart.get_xticklabels(), rotation=90)
    plt.show()


# In[58]:


df.columns


# In[59]:


pd.pivot_table(df, index=['job_title_simplified','job_seniority'], values='average_salary')


# In[60]:


pd.pivot_table(df, index=['job_state','job_title_simplified'], values='average_salary').sort_values('average_salary')


# In[61]:


pd.pivot_table(df, index='job_state', values='average_salary').sort_values('average_salary')


# In[62]:


pd.pivot_table(df, index='Industry', values='average_salary').sort_values('average_salary')


# In[63]:


pd.pivot_table(df, index='Sector', values='average_salary').sort_values('average_salary')


# In[64]:


pd.pivot_table(df, index='Type of ownership', values='average_salary').sort_values('average_salary')


# In[65]:


pd.pivot_table(df, index='Company Name', values='average_salary').sort_values('average_salary')


# In[66]:


df.Industry.unique()


# In[67]:


# trimming columns 1)industries 2)job_state
industry_list = ['Biotech & Pharmaceuticals', 'Insurance Carriers' ,'Computer Hardware & Software','Enterprise Software & Network Solutions', 'Consulting', 'Internet', 'Advertising & Marketing','Aerospace & Defense','Health Care Services & Hospitals','IT Services','Consumer Products Manufacturing']
def industry_simplifier(text):
    if text not in industry_list:
        return 'Others'
    else:
        return text

df['Industry'] = df['Industry'].apply(industry_simplifier)

job_state_list = ['CA','MA','NY','VA','IL','MD','PA','TX','NC','WA']
def job_state_simplifier(text):
    if text not in job_state_list:
        return 'Others'
    else:
        return text
    
df['job_state'] = df['job_state'].apply(job_state_simplifier)

#adding job_in_headquaters
df['job_in_headquarters'] = df.apply(lambda x:1 if x['Location'] == x['Headquarters'] else 0, axis=1)
df.columns


# In[68]:


df_model = df.copy(deep=True)
df_model = df_model[['average_salary','Rating','company_age','Size','Type of ownership','Industry','Revenue','Competitors','job_title_simplified','job_seniority','job_state','job_in_headquarters','python_job','spark_job','aws_job', 'excel_job']]
df_model.rename(columns={'Rating':'company_ratings','Size':'company_size','Type of ownership':'type_of_ownership','Industry':'industry','Revenue':'revenue','Competitors':'competitors'},inplace=True)
df_model.columns


# In[69]:


# math ranking (math meaning) => ordinal
size_map = {'Unknown':0 , '1 to 50 employees':1, '51 to 200 employees':2, '201 to 500 employees':3, '501 to 1000 employees':4, '1001 to 5000 employees':5, '5001 to 10000 employees':6}

df_model['company_size_rank']=df_model['company_size'].map(size_map)
df_model.drop('company_size', axis=True, inplace=True)

revenue_map = {'Unknown / Non-Applicable':0, 'Less than $1 million (USD)':1, '$1 to $5 million (USD)':2, '$5 to $10 million (USD)':3, '$10 to $25 million (USD)':4, '$25 to $50 million (USD)':5, '$50 to $100 million (USD)':6, '$100 to $500 million (USD)':7, '$500 to $1 billion (USD)':8, '$1 to $2 billion (USD)':9, '$2 to $5 billion (USD)':10}

df_model['company_revenue_rank']=df_model['revenue'].map(revenue_map)
df_model.drop('revenue', axis=True, inplace=True)

job_seniority_map = {'na':0, 'jr':1, 'senior':2}

df_model['job_seniority_rank']=df_model['job_seniority'].map(job_seniority_map)
df_model.drop('job_seniority', axis=True, inplace=True)


# In[70]:


df_model = pd.get_dummies(columns=['type_of_ownership'], data=df_model)
df_model.shape


# In[71]:


#columnd not having math meaning => nominal
df_model = pd.get_dummies(columns=['industry'], data=df_model)
df_model.shape


# In[72]:


df_model = pd.get_dummies(columns=['job_title_simplified'], data=df_model)
df_model.shape


# In[73]:


df_model = pd.get_dummies(columns=['job_state'], data=df_model)
df_model.shape


# In[74]:


df_model.head()


# In[75]:


# Dataset after Feature Engineering
df_model.shape

X = df_model.drop('average_salary', axis=1)
y = df_model['average_salary']
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
columns_to_scale = ['company_ratings', 'competitors', 'company_age', 'company_size_rank', 'company_revenue_rank']
X[columns_to_scale] = scaler.fit_transform(X[columns_to_scale])
# Splitting the dataset into train and test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=42)
print("Training set size: {} and Testing set size: {}".format(X_train.shape, X_test.shape))


# In[114]:


# Creating linear regression model
from sklearn.linear_model import LinearRegression
lr_model = LinearRegression()
# Fitting the dataset to the model
lr_model.fit(X_train, y_train)
print("Accuracy of the Linear Regression Model on Training set is : {}% and on Test set is {}%".format(round(lr_model.score(X_train, y_train),4)*100, round(lr_model.score(X_test, y_test),4)*100))


# In[110]:


from sklearn.neighbors import KNeighborsRegressor

# Create a KNeighborsRegressor object with k=5
knn_model = KNeighborsRegressor(n_neighbors=5)

# Fit the training data to the model
knn_model.fit(X_train, y_train)

# Print the accuracy of the KNN model on the training and test sets
print("Accuracy of the KNN Regression Model on Training set is : {}% and on Test set is {}%".format(round(knn_model.score(X_train, y_train),4)*100, round(knn_model.score(X_test, y_test),4)*100))


# In[102]:


# Creating decision tree regression model
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

import pandas
from sklearn.tree import DecisionTreeRegressor
decision_model = DecisionTreeRegressor(criterion='mse', max_depth=11, random_state=42)
# Fitting the dataset to the model
decision_model.fit(X_train, y_train)
print("Accuracy of the Decision Tree Regression Model on Training set is : {}% and on Test set is {}%".format(round(decision_model.score(X_train, y_train),4)*100, round(decision_model.score(X_test, y_test),4)*100))


# In[112]:


from sklearn.ensemble import GradientBoostingRegressor

# Create the model object
gb_model = GradientBoostingRegressor(n_estimators=250, learning_rate=0.1, random_state=42)

# Fit the dataset to the model
gb_model.fit(X_train, y_train)

# Evaluate the model
print("Accuracy of the Gradient Boosting Regression Model on Training set is : {}% and on Test set is {}%".format(round(gb_model.score(X_train, y_train),4)*100, round(gb_model.score(X_test, y_test),4)*100))


# In[103]:


# Creating random forest regression model
from sklearn.ensemble import RandomForestRegressor
forest_model = RandomForestRegressor(n_estimators=100, criterion='mse', random_state=42)
# Fitting the dataset to the model
forest_model.fit(X_train, y_train)
print("Accuracy of the Random Forest Regression Model on Training set is : {}% and on Test set is {}%".format(round(forest_model.score(X_train, y_train),4)*100, round(forest_model.score(X_test, y_test),4)*100))


# In[108]:


# Creating AdaBoost regression model
from sklearn.ensemble import AdaBoostRegressor
adb_model = AdaBoostRegressor(base_estimator=decision_model, n_estimators=250, learning_rate=1, random_state=42)
# Fitting the dataset to the model
adb_model.fit(X_train, y_train)
print("Accuracy of the AdaBoost Regression Model on Training set is : {}% and on Test set is {}%".format(round(adb_model.score(X_train, y_train),4)*100, round(adb_model.score(X_test, y_test),4)*100))


# In[ ]:




